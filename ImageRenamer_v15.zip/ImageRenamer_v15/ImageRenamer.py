import os, shutil, tempfile, zipfile, struct, subprocess, sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

EXTS={'.jpg','.jpeg','.png','.webp','.bmp','.tif','.tiff'}
class ImageRenamer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Image Renamer - 이미지 이름 변경기 v15')
        self.geometry('1250x820'); self.minsize(1050,700)
        self.files=[]; self.assignments={}
        self.card_selected=None; self.grid_selected=None
        self.row_labels=['A','B','C','D','E']; self.col_labels=['1','2','3','4','5']
        self.order_vars=[]
        self.thumb_refs=[]; self.grid_thumb_refs=[]; self.source_thumb_refs=[]
        self.build_ui(); self.refresh_all()

    # ---------- UI ----------
    def build_ui(self):
        top=ttk.Frame(self,padding=10); top.pack(fill='x')
        ttk.Label(top,text='이미지 이름 변경기',font=('맑은 고딕',18,'bold')).pack(side='left')
        ttk.Button(top,text='이미지 추가',command=self.add_files).pack(side='right',padx=4)
        ttk.Button(top,text='폴더에서 추가',command=self.add_folder).pack(side='right',padx=4)
        ttk.Button(top,text='목록 비우기',command=self.clear_files).pack(side='right',padx=4)

        nb=ttk.Notebook(self); nb.pack(fill='both',expand=True,padx=10,pady=(0,10))
        self.tab_batch=ttk.Frame(nb,padding=12); self.tab_grid=ttk.Frame(nb,padding=12); self.tab_settings=ttk.Frame(nb,padding=12)
        nb.add(self.tab_batch,text='① 일괄 이름 변경'); nb.add(self.tab_grid,text='② 엑셀식 이름 지정'); nb.add(self.tab_settings,text='③ 저장 / 메타데이터 / 순서')
        self.build_batch(); self.build_grid(); self.build_settings()

    def build_batch(self):
        f=self.tab_batch
        info=ttk.LabelFrame(f,text='일괄 변경',padding=10); info.pack(fill='x')
        ttk.Label(info,text='기본 이름').grid(row=0,column=0,sticky='w',padx=5,pady=4)
        self.base_var=tk.StringVar(value='A'); ttk.Entry(info,textvariable=self.base_var,width=24).grid(row=0,column=1,sticky='w',padx=5)
        ttk.Label(info,text='예: A 입력 → A_1, A_2, A_3 ...').grid(row=0,column=2,sticky='w',padx=10)
        ttk.Label(info,text='시작 번호').grid(row=1,column=0,sticky='w',padx=5,pady=4)
        self.start_var=tk.IntVar(value=1); ttk.Spinbox(info,from_=0,to=999999,textvariable=self.start_var,width=10,command=self.refresh_cards).grid(row=1,column=1,sticky='w',padx=5)
        self.base_var.trace_add('write',lambda *_:self.refresh_cards())
        self.start_var.trace_add('write',lambda *_:self.refresh_cards())

        ex=ttk.LabelFrame(f,text='이름 변경 예시',padding=8); ex.pack(fill='x',pady=(7,5))
        self.example_label=ttk.Label(ex,text='',justify='left'); self.example_label.pack(anchor='w')

        bar=ttk.Frame(f); bar.pack(fill='x',pady=5)
        ttk.Button(bar,text='▲ 선택 이미지 위로',command=lambda:self.move_selected(-1)).pack(side='left',padx=3)
        ttk.Button(bar,text='▼ 선택 이미지 아래로',command=lambda:self.move_selected(1)).pack(side='left',padx=3)
        ttk.Button(bar,text='선택 삭제',command=self.remove_selected).pack(side='left',padx=3)
        ttk.Label(bar,text='※ 이미지 카드를 드래그해서 순서를 바꾸는 기능은 제거했습니다.').pack(side='left',padx=12)

        viewer=ttk.Frame(f); viewer.pack(fill='both',expand=True,pady=4)
        self.card_canvas=tk.Canvas(viewer,highlightthickness=0,bg='#d7d9dc')
        self.card_scroll=ttk.Scrollbar(viewer,orient='vertical',command=self.card_canvas.yview)
        self.card_canvas.configure(yscrollcommand=self.card_scroll.set)
        self.card_canvas.pack(side='left',fill='both',expand=True); self.card_scroll.pack(side='right',fill='y')
        self.card_inner=tk.Frame(self.card_canvas,bg='#d7d9dc')
        self.card_window=self.card_canvas.create_window((0,0),window=self.card_inner,anchor='nw')
        self.card_inner.bind('<Configure>',lambda e:self.card_canvas.configure(scrollregion=self.card_canvas.bbox('all')))
        self.card_canvas.bind('<Configure>',lambda e:self.card_canvas.itemconfigure(self.card_window,width=e.width))

    def build_grid(self):
        f=self.tab_grid
        left=ttk.Frame(f); left.pack(side='left',fill='y',padx=(0,12))
        ttk.Label(left,text='이미지 목록 (클릭 후 표의 칸 지정)',font=('맑은 고딕',11,'bold')).pack(anchor='w')
        source=ttk.Frame(left); source.pack(fill='both',expand=True,pady=8)
        self.source_canvas=tk.Canvas(source,width=285,highlightthickness=0,bg='#d7d9dc')
        ss=ttk.Scrollbar(source,orient='vertical',command=self.source_canvas.yview)
        self.source_canvas.configure(yscrollcommand=ss.set); self.source_canvas.pack(side='left',fill='both',expand=True); ss.pack(side='right',fill='y')
        self.source_inner=tk.Frame(self.source_canvas,bg='#d7d9dc'); self.source_window=self.source_canvas.create_window((0,0),window=self.source_inner,anchor='nw')
        self.source_inner.bind('<Configure>',lambda e:self.source_canvas.configure(scrollregion=self.source_canvas.bbox('all')))
        ttk.Button(left,text='선택한 이미지 제거',command=self.remove_grid_source).pack(fill='x')

        right=ttk.Frame(f); right.pack(side='left',fill='both',expand=True)
        controls=ttk.Frame(right); controls.pack(fill='x',pady=(0,8))
        ttk.Label(controls,text='행 개수').pack(side='left'); self.rows_var=tk.IntVar(value=5); ttk.Spinbox(controls,from_=1,to=26,textvariable=self.rows_var,width=5).pack(side='left',padx=5)
        ttk.Label(controls,text='열 개수').pack(side='left',padx=(12,0)); self.cols_var=tk.IntVar(value=5); ttk.Spinbox(controls,from_=1,to=50,textvariable=self.cols_var,width=5).pack(side='left',padx=5)
        ttk.Button(controls,text='표 크기 적용',command=self.apply_grid_size).pack(side='left',padx=8)
        box=ttk.LabelFrame(right,text='행 / 열 이름 직접 변경',padding=8); box.pack(fill='x',pady=(0,8)); box.columnconfigure(1,weight=1)
        ttk.Label(box,text='행 이름:').grid(row=0,column=0,sticky='w'); self.row_entry=ttk.Entry(box); self.row_entry.insert(0,','.join(self.row_labels)); self.row_entry.grid(row=0,column=1,sticky='ew',padx=6); ttk.Label(box,text='예: A,B,C,D,E → 5행 / A → 1행').grid(row=0,column=2,sticky='w')
        ttk.Label(box,text='열 이름:').grid(row=1,column=0,sticky='w',pady=(6,0)); self.col_entry=ttk.Entry(box); self.col_entry.insert(0,','.join(self.col_labels)); self.col_entry.grid(row=1,column=1,sticky='ew',padx=6,pady=(6,0)); ttk.Label(box,text='예: 1,2,3,4,5 → 5열 / 1 → 1열').grid(row=1,column=2,sticky='w',pady=(6,0))
        ttk.Button(box,text='행/열 이름 적용',command=self.apply_grid_labels).grid(row=0,column=3,rowspan=2,padx=8)

        # Scrollable spreadsheet area: vertical + horizontal
        sheet=ttk.Frame(right); sheet.pack(fill='both',expand=True)
        self.sheet_canvas=tk.Canvas(sheet,highlightthickness=0,bg='#d7d9dc')
        self.sheet_v=ttk.Scrollbar(sheet,orient='vertical',command=self.sheet_canvas.yview)
        self.sheet_h=ttk.Scrollbar(sheet,orient='horizontal',command=self.sheet_canvas.xview)
        self.sheet_canvas.configure(yscrollcommand=self.sheet_v.set,xscrollcommand=self.sheet_h.set)
        self.sheet_canvas.grid(row=0,column=0,sticky='nsew'); self.sheet_v.grid(row=0,column=1,sticky='ns'); self.sheet_h.grid(row=1,column=0,sticky='ew')
        sheet.rowconfigure(0,weight=1); sheet.columnconfigure(0,weight=1)
        self.grid_frame=tk.Frame(self.sheet_canvas,bg='#d7d9dc')
        self.grid_window=self.sheet_canvas.create_window((0,0),window=self.grid_frame,anchor='nw')
        self.grid_frame.bind('<Configure>',lambda e:self.sheet_canvas.configure(scrollregion=self.sheet_canvas.bbox('all')))
        ttk.Label(right,text='★ 각 셀 전체가 넓은 클릭 영역입니다. [＋ 이미지 넣기]로 파일을 직접 선택할 수도 있습니다.',foreground='#315a43',font=('맑은 고딕',10,'bold')).pack(anchor='w',pady=(8,2))
        ttk.Label(right,text='표가 커지면 오른쪽/아래 스크롤을 사용하세요.',foreground='#53657a').pack(anchor='w',pady=(0,6))
        self.grid_status=ttk.Label(right,text=''); self.grid_status.pack(anchor='w')

    def build_settings(self):
        f=self.tab_settings
        mode=ttk.LabelFrame(f,text='이름 변경 대상',padding=12); mode.pack(fill='x',pady=(0,10))
        self.source_mode=tk.StringVar(value='copy')
        ttk.Radiobutton(mode,text='원본 파일 자체의 이름을 변경',variable=self.source_mode,value='rename').pack(anchor='w',pady=3)
        ttk.Radiobutton(mode,text='원본은 그대로 두고 별도 폴더로 복사하여 이름 변경',variable=self.source_mode,value='copy').pack(anchor='w',pady=3)
        ex=ttk.LabelFrame(f,text='EXIF / 메타데이터',padding=12); ex.pack(fill='x',pady=10)
        self.remove_metadata_var=tk.BooleanVar(value=True)
        ttk.Checkbutton(ex,text='EXIF / 메타데이터 제거 (체크하면 제거, 체크 해제하면 원본 메타데이터 유지)',variable=self.remove_metadata_var).pack(anchor='w')
        ttk.Label(ex,text='체크 시 JPG/PNG/WebP는 파일 내부 구조를 검사해 EXIF, XMP, IPTC, ICC 프로필, 주석 및 부가 메타데이터를 제거합니다. BMP/TIFF도 메타데이터를 복사하지 않고 다시 저장한 뒤 검사합니다.',foreground='#53657a',wraplength=900).pack(anchor='w',pady=(5,0))
        out=ttk.LabelFrame(f,text='저장 방식',padding=12); out.pack(fill='x',pady=10)
        self.save_mode=tk.StringVar(value='folder')
        ttk.Radiobutton(out,text='일반 폴더로 저장',variable=self.save_mode,value='folder').pack(anchor='w',pady=3)
        ttk.Radiobutton(out,text='ZIP 압축파일로 저장',variable=self.save_mode,value='zip').pack(anchor='w',pady=3)
        fmt=ttk.LabelFrame(f,text='저장 파일 형식',padding=12); fmt.pack(fill='x',pady=10)
        self.format_var=tk.StringVar(value='원본 형식')
        ttk.Radiobutton(fmt,text='원본 형식',variable=self.format_var,value='원본 형식').pack(side='left',padx=8)
        ttk.Radiobutton(fmt,text='JPG',variable=self.format_var,value='JPG').pack(side='left',padx=8)
        ttk.Radiobutton(fmt,text='PNG',variable=self.format_var,value='PNG').pack(side='left',padx=8)
        ttk.Radiobutton(fmt,text='WebP',variable=self.format_var,value='WebP').pack(side='left',padx=8)
        ttk.Button(f,text='이름 변경 실행',command=self.execute,width=24).pack(pady=22)

    # ---------- data / thumbnails ----------
    def _thumb(self,path,size=(220,150)):
        try:
            im=Image.open(path).convert('RGB'); im.thumbnail(size,Image.Resampling.LANCZOS)
            bg=Image.new('RGB',size,'#eceef0'); bg.paste(im,((size[0]-im.width)//2,(size[1]-im.height)//2)); return ImageTk.PhotoImage(bg)
        except Exception:return None

    def add_files(self):
        paths=filedialog.askopenfilenames(title='이미지 선택',filetypes=[('Image files','*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff'),('All files','*.*')]); self.add_paths(paths)
    def add_folder(self):
        folder=filedialog.askdirectory(title='이미지 폴더 선택')
        if folder:self.add_paths([str(p) for p in sorted(Path(folder).iterdir()) if p.is_file() and p.suffix.lower() in EXTS])
    def add_paths(self,paths):
        for p in paths:
            if p not in self.files:self.files.append(p)
        self.refresh_all()
    def clear_files(self):self.files.clear();self.assignments.clear();self.card_selected=None;self.grid_selected=None;self.refresh_all()

    def refresh_all(self):
        if self.card_selected is not None and self.card_selected>=len(self.files):self.card_selected=None
        if self.grid_selected is not None and self.grid_selected>=len(self.files):self.grid_selected=None
        self.refresh_cards(); self.refresh_sources(); self.rebuild_grid()

    def refresh_cards(self):
        for w in self.card_inner.winfo_children():w.destroy()
        self.thumb_refs=[]; self.order_vars=[]
        cols=4
        for idx,path in enumerate(self.files):
            selected=(self.card_selected==idx)
            card=tk.Frame(self.card_inner,bg='#eef0f2',highlightthickness=2,highlightbackground=('#4aa3df' if selected else '#aeb5bd'),width=270,height=285)
            card.grid(row=idx//cols,column=idx%cols,padx=7,pady=7,sticky='n'); card.grid_propagate(False)
            tk.Label(card,text=str(idx+1),bg='#eef0f2',fg='#345',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=7,pady=(5,0))
            im=self._thumb(path,(245,160))
            if im:
                self.thumb_refs.append(im); lab=tk.Label(card,image=im,bg='#eceef0'); lab.pack(padx=7,pady=5); lab.bind('<Button-1>',lambda e,i=idx:self.select_card(i))
            tk.Label(card,text=Path(path).name,wraplength=245,justify='left',bg='#eef0f2',fg='#4d5864').pack(padx=7)
            row=tk.Frame(card,bg='#eef0f2'); row.pack(fill='x',padx=7,pady=5)
            ttk.Label(row,text='순서').pack(side='left')
            ov=tk.StringVar(value=str(idx+1)); self.order_vars.append(ov)
            ent=ttk.Entry(row,textvariable=ov,width=6,justify='center'); ent.pack(side='left',padx=4)
            ent.bind('<Return>',lambda e:self.apply_numeric_order()); ent.bind('<FocusOut>',lambda e:self.apply_numeric_order())
            ttk.Label(card,text=self.batch_name_for_index(idx),foreground='#315a43').pack(padx=7,anchor='w')
        self.card_inner.update_idletasks(); self.card_canvas.configure(scrollregion=self.card_canvas.bbox('all'))
        self.update_batch_example()

    def select_card(self,idx):self.card_selected=idx;self.refresh_cards()

    def batch_name_for_index(self,idx):
        base=self.clean(self.base_var.get() or 'A'); start=int(self.start_var.get() or 1)
        # Numeric order controls the suffix assignment, not the visual position.
        n=idx+start
        if idx < len(self.order_vars):
            try:n=int(self.order_vars[idx].get())
            except Exception:pass
        return f'{base}_{n}'

    def update_batch_example(self):
        if not self.files:
            self.example_label.config(text='예: A 입력 → A_1, A_2, A_3 …')
            return
        parts=[]
        for i,path in enumerate(self.files[:8]):
            parts.append(f'{i+1}번 이미지 → {self.batch_name_for_index(i)}')
        if len(self.files)>8:parts.append('…')
        self.example_label.config(text='\n'.join(parts))

    def apply_numeric_order(self):
        if not self.files:return
        vals=[]
        for i in range(len(self.files)):
            try:v=int(self.order_vars[i].get())
            except Exception:v=i+1
            vals.append((v,i))
        # Stable sort: duplicate numbers retain current order.
        order=[i for _,i in sorted(vals,key=lambda x:x[0])]
        old_files=self.files[:]; self.files=[old_files[i] for i in order]
        old_assign=self.assignments.copy(); index_map={old:new for new,old in enumerate(order)}
        self.assignments={cell:index_map[idx] for cell,idx in old_assign.items() if idx in index_map}
        self.card_selected=None
        self.refresh_all()

    def move_selected(self,delta):
        i=self.card_selected
        if i is None or not self.files:return
        j=i+delta
        if j<0 or j>=len(self.files):return
        self.files[i],self.files[j]=self.files[j],self.files[i]
        for cell,old in list(self.assignments.items()):
            if old==i:self.assignments[cell]=j
            elif old==j:self.assignments[cell]=i
        self.card_selected=j; self.refresh_all()

    def remove_selected(self):
        i=self.card_selected
        if i is None:return
        self.files.pop(i); self.assignments={(r,c):(v-1 if v>i else v) for (r,c),v in self.assignments.items() if v!=i}; self.card_selected=None; self.refresh_all()

    # ---------- spreadsheet ----------
    def refresh_sources(self):
        for w in self.source_inner.winfo_children():w.destroy()
        self.source_thumb_refs=[]
        for idx,path in enumerate(self.files):
            selected=(self.grid_selected==idx)
            card=tk.Frame(self.source_inner,bg='#eef0f2',highlightthickness=2,highlightbackground=('#4aa3df' if selected else '#aeb5bd'))
            card.pack(fill='x',padx=5,pady=5)
            card.bind('<Button-1>',lambda e,i=idx:self.select_grid_source(i))
            im=self._thumb(path,(245,125))
            if im:
                self.source_thumb_refs.append(im); lab=tk.Label(card,image=im,bg='#eceef0'); lab.pack(padx=5,pady=5); lab.bind('<Button-1>',lambda e,i=idx:self.select_grid_source(i))
            lab=tk.Label(card,text=f'{idx+1}. {Path(path).name}',wraplength=245,justify='left',bg='#eef0f2',fg='#4d5864'); lab.pack(padx=6,pady=(0,6)); lab.bind('<Button-1>',lambda e,i=idx:self.select_grid_source(i))
        self.source_inner.update_idletasks(); self.source_canvas.configure(scrollregion=self.source_canvas.bbox('all'))

    def select_grid_source(self,idx):self.grid_selected=idx;self.refresh_sources()
    def remove_grid_source(self):
        idx=self.grid_selected
        if idx is None:return
        self.files.pop(idx); self.assignments={(r,c):(v-1 if v>idx else v) for (r,c),v in self.assignments.items() if v!=idx}; self.grid_selected=None; self.refresh_all()

    def _resize_grid(self,new_rows,new_cols):
        new_rows=max(1,int(new_rows)); new_cols=max(1,int(new_cols))
        deleted=[f'{self.row_labels[r]}_{self.col_labels[c]}' for (r,c) in self.assignments if r>=new_rows or c>=new_cols]
        if deleted:
            preview=', '.join(deleted[:10]) + (f' 외 {len(deleted)-10}개' if len(deleted)>10 else '')
            if not messagebox.askyesno('이미지가 있는 행/열 삭제',
                f'표 크기가 {len(self.row_labels)}×{len(self.col_labels)} → {new_rows}×{new_cols}로 변경됩니다.\n\n'
                f'삭제되는 칸에 이미지가 {len(deleted)}개 있습니다.\n삭제 대상: {preview}\n\n계속하면 해당 이미지 지정이 삭제됩니다.\n계속할까요?'):
                return False
        while len(self.row_labels)<new_rows:self.row_labels.append(chr(65+len(self.row_labels)))
        while len(self.col_labels)<new_cols:self.col_labels.append(str(len(self.col_labels)+1))
        self.row_labels=self.row_labels[:new_rows]; self.col_labels=self.col_labels[:new_cols]
        self.rows_var.set(new_rows); self.cols_var.set(new_cols)
        self.assignments={(r,c):idx for (r,c),idx in self.assignments.items() if r<new_rows and c<new_cols}
        self.rebuild_grid()
        return True

    def apply_grid_size(self):
        self._resize_grid(self.rows_var.get(),self.cols_var.get())

    def apply_grid_labels(self):
        r=[x.strip() for x in self.row_entry.get().split(',') if x.strip()]
        c=[x.strip() for x in self.col_entry.get().split(',') if x.strip()]
        if not r or not c:
            messagebox.showerror('행/열 이름','행과 열 이름을 각각 하나 이상 입력하세요.')
            return
        deleted=[f'{self.row_labels[rr]}_{self.col_labels[cc]}' for (rr,cc) in self.assignments if rr>=len(r) or cc>=len(c)]
        if deleted:
            preview=', '.join(deleted[:10]) + (f' 외 {len(deleted)-10}개' if len(deleted)>10 else '')
            if not messagebox.askyesno('이미지가 있는 행/열 삭제',
                f'표 크기가 {len(self.row_labels)}×{len(self.col_labels)} → {len(r)}×{len(c)}로 변경됩니다.\n\n'
                f'삭제되는 칸에 이미지가 {len(deleted)}개 있습니다.\n삭제 대상: {preview}\n\n계속하면 해당 이미지 지정이 삭제됩니다.\n계속할까요?'):
                return
        self.row_labels=r; self.col_labels=c; self.rows_var.set(len(r)); self.cols_var.set(len(c))
        self.assignments={(rr,cc):idx for (rr,cc),idx in self.assignments.items() if rr<len(r) and cc<len(c)}
        self.rebuild_grid()

    def rebuild_grid(self):
        if not hasattr(self,'grid_frame'): return
        for w in self.grid_frame.winfo_children(): w.destroy()
        self.grid_thumb_refs=[]
        self.grid_rows=max(1,int(self.rows_var.get())); self.grid_cols=max(1,int(self.cols_var.get()))
        self.row_labels=self.row_labels[:self.grid_rows]; self.col_labels=self.col_labels[:self.grid_cols]
        while len(self.row_labels)<self.grid_rows:self.row_labels.append(chr(65+len(self.row_labels)))
        while len(self.col_labels)<self.grid_cols:self.col_labels.append(str(len(self.col_labels)+1))
        self.row_entry.delete(0,'end'); self.row_entry.insert(0,','.join(self.row_labels))
        self.col_entry.delete(0,'end'); self.col_entry.insert(0,','.join(self.col_labels))
        ttk.Label(self.grid_frame,text='').grid(row=0,column=0,padx=3,pady=3)
        for c in range(self.grid_cols): ttk.Label(self.grid_frame,text=self.col_labels[c],anchor='center',width=16).grid(row=0,column=c+1,padx=3,pady=3)
        for r in range(self.grid_rows):
            ttk.Label(self.grid_frame,text=self.row_labels[r],anchor='center',width=12).grid(row=r+1,column=0,padx=3,pady=3)
            for c in range(self.grid_cols):
                cell=tk.Frame(self.grid_frame,bg='#eef0f2',highlightthickness=2,highlightbackground='#aeb5bd',width=190,height=190,cursor='hand2')
                cell.grid(row=r+1,column=c+1,padx=5,pady=5); cell.grid_propagate(False)
                idx=self.assignments.get((r,c)); title=f'{self.row_labels[r]}_{self.col_labels[c]}'
                tk.Button(cell,text=title,relief='flat',bd=0,bg='#eef0f2',fg='#3f5368',activebackground='#dce2e7',
                          cursor='hand2',font=('맑은 고딕',11,'bold'),command=lambda rr=r,cc=c:self.assign_cell(rr,cc)).pack(fill='x',padx=8,pady=(6,4))
                if idx is not None and idx<len(self.files):
                    im=self._thumb(self.files[idx],(165,100))
                    if im:
                        self.grid_thumb_refs.append(im); lab=tk.Label(cell,image=im,bg='#e3e6e9',cursor='hand2'); lab.pack(padx=8,pady=2); lab.bind('<Button-1>',lambda e,rr=r,cc=c:self.assign_cell(rr,cc))
                    lab=tk.Label(cell,text=Path(self.files[idx]).name[:24],bg='#eef0f2',fg='#68727d',wraplength=165,cursor='hand2'); lab.pack(padx=6,pady=2); lab.bind('<Button-1>',lambda e,rr=r,cc=c:self.assign_cell(rr,cc))
                    ttk.Button(cell,text='이미지 교체',command=lambda rr=r,cc=c:self.pick_image_for_cell(rr,cc)).pack(pady=2)
                else:
                    ttk.Label(cell,text='이미지 없음',background='#eef0f2',foreground='#8a939c').pack(pady=(6,2))
                    ttk.Button(cell,text='＋ 이미지 넣기',command=lambda rr=r,cc=c:self.pick_image_for_cell(rr,cc)).pack(pady=4)
                ttk.Button(cell,text='현재 선택 이미지 넣기',command=lambda rr=r,cc=c:self.assign_cell(rr,cc)).pack(fill='x',padx=8,pady=(3,6))
        self.grid_status.config(text=f'지정된 칸: {len(self.assignments)}개')
        self.grid_frame.update_idletasks(); self.sheet_canvas.configure(scrollregion=self.sheet_canvas.bbox('all'))

    def pick_image_for_cell(self,r,c):
        paths=filedialog.askopenfilenames(title=f'{self.row_labels[r]}_{self.col_labels[c]} 이미지 선택',
            filetypes=[('이미지 파일','*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff'),('모든 파일','*.*')])
        if not paths:return
        known={str(Path(x).resolve()):i for i,x in enumerate(self.files)}
        first=str(Path(paths[0]).resolve())
        if first in known:idx=known[first]
        else:self.files.append(first);idx=len(self.files)-1
        known={str(Path(x).resolve()) for x in self.files}
        for raw in paths[1:]:
            q=str(Path(raw).resolve())
            if q not in known:self.files.append(q);known.add(q)
        self.grid_selected=idx;self.assignments[(r,c)]=idx;self.refresh_all()

    def remove_cell_image(self,r,c):
        self.assignments.pop((r,c),None); self.rebuild_grid()

    def assign_cell(self,r,c):
        idx=self.grid_selected
        if idx is None:
            messagebox.showinfo('이미지 선택','왼쪽 이미지 목록에서 먼저 이미지를 선택하세요.\n또는 셀의 [＋ 이미지 넣기] 버튼을 사용하세요.')
            return
        if idx>=len(self.files): self.grid_selected=None; return
        self.assignments[(r,c)]=idx; self.rebuild_grid()

    # ---------- save ----------
    def jobs(self):
        if not self.files:raise ValueError('이미지를 먼저 추가하세요.')
        if self.assignments:
            out=[]
            for r in range(self.grid_rows):
                for c in range(self.grid_cols):
                    idx=self.assignments.get((r,c))
                    if idx is not None and idx<len(self.files):out.append((self.files[idx],f'{self.row_labels[r]}_{self.col_labels[c]}'))
            return out
        base=self.clean(self.base_var.get().strip())
        if not base:raise ValueError('기본 이름을 입력하세요.')
        # Use the numeric order values currently shown on cards.
        result=[]
        for i,p in enumerate(self.files):
            try:n=int(self.order_vars[i].get())
            except Exception:n=int(self.start_var.get())+i
            result.append((p,f'{base}_{n}'))
        return result

    def clean(self,s):
        for ch in '<>:"/\\|?*':s=s.replace(ch,'_')
        return s.strip()
    def choose_output(self):
        if self.save_mode.get()=='zip':
            return filedialog.asksaveasfilename(title='ZIP 저장',defaultextension='.zip',filetypes=[('ZIP','*.zip')])
        return filedialog.askdirectory(title='결과 폴더 선택')

    def output_ext(self,src):
        f=self.format_var.get()
        return { 'JPG':'.jpg','PNG':'.png','WebP':'.webp' }.get(f,Path(src).suffix.lower())

    def _exiftool_path(self):
        # Optional ExifTool executable can be placed beside the script or EXE.
        base = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
        candidates = [base / 'exiftool.exe', base / 'tools' / 'exiftool.exe']
        for candidate in candidates:
            if candidate.exists():
                return str(candidate)
        from shutil import which
        return which('exiftool') or which('exiftool.exe')

    def _strip_jpeg_metadata(self, src, dst):
        # Lossless JPEG marker filtering: compressed image scan data is copied byte-for-byte.
        data = Path(src).read_bytes()
        if not data.startswith(b'\xff\xd8'):
            raise ValueError('JPEG 헤더가 올바르지 않습니다.')
        out = bytearray(data[:2]); pos = 2; n = len(data)
        while pos < n:
            if data[pos] != 0xFF:
                # Entropy-coded scan: copy through end of file unchanged.
                out.extend(data[pos:]); break
            marker_start = pos
            while pos < n and data[pos] == 0xFF: pos += 1
            if pos >= n: out.extend(data[marker_start:]); break
            marker = data[pos]; pos += 1
            if marker == 0xD9:  # EOI
                out.extend(data[marker_start:pos]); out.extend(data[pos:]); break
            if marker == 0xDA:  # SOS: copy scan data, respecting stuffed FF00 and restart markers
                if pos + 2 > n: raise ValueError('JPEG SOS 세그먼트가 손상되었습니다.')
                seglen = int.from_bytes(data[pos:pos+2], 'big')
                if seglen < 2 or pos + seglen > n: raise ValueError('JPEG 세그먼트 길이가 올바르지 않습니다.')
                scan_start = pos + seglen
                q = scan_start
                while q < n - 1:
                    if data[q] == 0xFF:
                        nxt = data[q+1]
                        if nxt == 0x00 or 0xD0 <= nxt <= 0xD7:
                            q += 2; continue
                        if nxt == 0xFF:
                            q += 1; continue
                        break
                    q += 1
                out.extend(data[marker_start:q])
                pos = q
                continue
            if marker in (0xD8,) or 0xD0 <= marker <= 0xD7 or marker == 0x01:
                out.extend(data[marker_start:pos]); continue
            if pos + 2 > n: raise ValueError('JPEG 세그먼트가 손상되었습니다.')
            seglen = int.from_bytes(data[pos:pos+2], 'big')
            end = pos + seglen
            if seglen < 2 or end > n: raise ValueError('JPEG 세그먼트 길이가 올바르지 않습니다.')
            payload = data[pos+2:end]
            # Strip every APPn segment (APP0-APP15), including JFIF, EXIF, XMP, ICC, IPTC/Photoshop and vendor metadata, plus COM.
            # Keep only JPEG coding/quantization/Huffman/restart/scan markers.
            remove = (0xE0 <= marker <= 0xEF) or marker == 0xFE
            if not remove:
                out.extend(data[marker_start:end])
            pos = end
        Path(dst).write_bytes(out)

    def _strip_png_metadata(self, src, dst):
        # PNG chunks are removed without decoding or recompressing image pixels.
        data = Path(src).read_bytes()
        if not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('PNG 헤더가 올바르지 않습니다.')
        out = bytearray(data[:8]); pos = 8; n = len(data)
        # PNG critical chunks have an uppercase first letter. Strip every ancillary
        # chunk (lowercase first letter), including eXIf, text, iCCP, timestamps,
        # physical dimensions, animation metadata, and unknown ancillary chunks.
        remove_types = set()
        while pos + 12 <= n:
            length = int.from_bytes(data[pos:pos+4], 'big')
            end = pos + 12 + length
            if end > n: raise ValueError('PNG 청크 길이가 올바르지 않습니다.')
            kind = data[pos+4:pos+8]
            # Drop ancillary metadata chunks, but preserve tRNS (visual transparency)
            # and APNG animation chunks because they affect the actual image content.
            keep_ancillary = {b'tRNS', b'acTL', b'fcTL', b'fdAT'}
            if not (kind and 97 <= kind[0] <= 122) or kind in keep_ancillary:
                out.extend(data[pos:end])
            pos = end
            if kind == b'IEND':
                out.extend(data[pos:]); break
        Path(dst).write_bytes(out)

    def _strip_webp_metadata(self, src, dst):
        # Losslessly remove WebP metadata chunks. VP8X feature flags are updated
        # when ICC/EXIF/XMP chunks are removed; image/alpha/animation data stays intact.
        data = Path(src).read_bytes()
        if len(data) < 12 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
            raise ValueError('WebP 헤더가 올바르지 않습니다.')
        chunks=[]; pos=12; n=len(data)
        removed={b'EXIF', b'XMP ', b'ICCP'}
        while pos + 8 <= n:
            kind=data[pos:pos+4]; length=int.from_bytes(data[pos+4:pos+8],'little')
            end=pos+8+length+(length&1)
            if end>n: raise ValueError('WebP 청크 길이가 올바르지 않습니다.')
            chunk=bytearray(data[pos:end])
            if kind not in removed:
                if kind == b'VP8X' and length >= 10:
                    # VP8X flags byte: ICCP=0x20, EXIF=0x08, XMP=0x04.
                    chunk[8] &= ~(0x20 | 0x08 | 0x04)
                chunks.append(bytes(chunk))
            pos=end
        body=b'WEBP'+b''.join(chunks)
        Path(dst).write_bytes(b'RIFF'+len(body).to_bytes(4,'little')+body)

    def _strip_metadata_lossless(self, src, dst):
        ext=Path(src).suffix.lower()
        # Remove metadata at the file-container level where possible. TIFF is rebuilt
        # from decoded pixels so tags/profiles from the source are not copied.
        if ext in ('.jpg','.jpeg'):
            self._strip_jpeg_metadata(src,dst)
        elif ext=='.png':
            self._strip_png_metadata(src,dst)
        elif ext=='.webp':
            self._strip_webp_metadata(src,dst)
        elif ext=='.bmp':
            # Rebuild BMP from decoded pixels so nonstandard/V5 metadata and profiles are not copied.
            with Image.open(src) as im:
                im.load()
                clean=im.convert('RGBA' if 'A' in im.getbands() else 'RGB')
                try: clean.save(dst, format='BMP')
                finally: clean.close()
        elif ext in ('.tif', '.tiff'):
            # Re-encode decoded pixels without passing EXIF, ICC, XMP or other tags.
            with Image.open(src) as im:
                im.seek(0); im.load()
                clean = im.convert('RGBA' if 'A' in im.getbands() else 'RGB')
                try:
                    clean.save(dst, format='TIFF', compression='tiff_deflate')
                finally:
                    clean.close()
        else:
            raise RuntimeError('지원하지 않는 이미지 형식입니다: ' + ext)

    def _verify_metadata_removed(self, path):
        """Fail closed if known metadata containers remain in the output file."""
        path = Path(path)
        ext = path.suffix.lower()
        data = path.read_bytes()
        if ext in ('.jpg', '.jpeg'):
            if not data.startswith(b'\xff\xd8'):
                raise RuntimeError('저장된 JPEG 파일 헤더 검증에 실패했습니다.')
            pos, n = 2, len(data)
            while pos < n:
                if data[pos] != 0xff:
                    raise RuntimeError('JPEG 구조 검증에 실패했습니다. 메타데이터 제거 결과를 안전하게 확인할 수 없습니다.')
                start = pos
                while pos < n and data[pos] == 0xff:
                    pos += 1
                if pos >= n:
                    break
                marker = data[pos]; pos += 1
                if marker == 0xd9:
                    break
                if marker == 0xda:
                    if pos + 2 > n: raise RuntimeError('JPEG 스캔 구조가 손상되었습니다.')
                    length = int.from_bytes(data[pos:pos+2], 'big')
                    if length < 2 or pos + length > n: raise RuntimeError('JPEG 스캔 길이가 올바르지 않습니다.')
                    q = pos + length
                    while q < n - 1:
                        if data[q] == 0xff:
                            nxt = data[q+1]
                            if nxt == 0x00 or 0xd0 <= nxt <= 0xd7: q += 2; continue
                            if nxt == 0xff: q += 1; continue
                            break
                        q += 1
                    pos = q
                    continue
                if marker == 0xd8 or 0xd0 <= marker <= 0xd7 or marker == 0x01:
                    continue
                if pos + 2 > n: raise RuntimeError('JPEG 세그먼트가 손상되었습니다.')
                length = int.from_bytes(data[pos:pos+2], 'big')
                end = pos + length
                if length < 2 or end > n: raise RuntimeError('JPEG 세그먼트 길이가 올바르지 않습니다.')
                if 0xe0 <= marker <= 0xef or marker == 0xfe:
                    raise RuntimeError(f'JPEG 내부에 제거되지 않은 메타데이터 세그먼트가 있습니다 (0xFF{marker:02X}).')
                pos = end
            return True
        if ext == '.png':
            if not data.startswith(b'\x89PNG\r\n\x1a\n'):
                raise RuntimeError('저장된 PNG 파일 헤더 검증에 실패했습니다.')
            pos, n = 8, len(data)
            keep = {b'tRNS', b'acTL', b'fcTL', b'fdAT'}
            while pos + 12 <= n:
                length = int.from_bytes(data[pos:pos+4], 'big')
                end = pos + 12 + length
                if end > n: raise RuntimeError('PNG 청크 구조가 손상되었습니다.')
                kind = data[pos+4:pos+8]
                if kind and 97 <= kind[0] <= 122 and kind not in keep:
                    raise RuntimeError('PNG 내부에 제거되지 않은 부가 청크가 있습니다: ' + kind.decode('ascii','replace'))
                pos = end
                if kind == b'IEND':
                    if pos != n: raise RuntimeError('PNG IEND 뒤에 추가 데이터가 남아 있습니다.')
                    return True
            raise RuntimeError('PNG 종료 청크(IEND)를 찾지 못했습니다.')
        if ext == '.webp':
            if len(data) < 12 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
                raise RuntimeError('저장된 WebP 파일 헤더 검증에 실패했습니다.')
            pos, n = 12, len(data)
            while pos + 8 <= n:
                kind = data[pos:pos+4]
                length = int.from_bytes(data[pos+4:pos+8], 'little')
                end = pos + 8 + length + (length & 1)
                if end > n: raise RuntimeError('WebP 청크 구조가 손상되었습니다.')
                if kind in {b'EXIF', b'XMP ', b'ICCP'}:
                    raise RuntimeError('WebP 내부에 제거되지 않은 메타데이터 청크가 있습니다: ' + kind.decode('ascii','replace'))
                if kind == b'VP8X' and length >= 10 and (data[pos+8] & (0x20 | 0x08 | 0x04)):
                    raise RuntimeError('WebP VP8X 헤더에 메타데이터 플래그가 남아 있습니다.')
                pos = end
            if pos != n: raise RuntimeError('WebP 끝부분에 해석되지 않은 데이터가 있습니다.')
            return True
        if ext == '.bmp':
            with Image.open(path) as im:
                if any(k.lower() in {'exif','xmp','icc_profile','iptc','photoshop'} for k in im.info):
                    raise RuntimeError('BMP 내부에 메타데이터가 남아 있습니다.')
            return True
        if ext in ('.tif', '.tiff'):
            with Image.open(path) as im:
                info_keys = {str(k).lower() for k in im.info}
                known = {'exif', 'xmp', 'icc_profile', 'iptc', 'photoshop', 'description', 'artist', 'copyright', 'datetime', 'documentname', 'software', 'make', 'model', 'gpsinfo'}
                if info_keys & known:
                    raise RuntimeError('TIFF 내부에 메타데이터가 남아 있습니다: ' + ', '.join(sorted(info_keys & known)))
                # Ignore mandatory TIFF image-layout tags; reject descriptive/device/GPS tags.
                metadata_tags = {270, 271, 272, 305, 306, 315, 33432, 34665, 34853, 40091, 40092, 40093, 40094, 40095, 700, 33723, 34377}
                try:
                    exif = im.getexif()
                    found = metadata_tags.intersection(set(exif.keys()))
                    if found:
                        raise RuntimeError('TIFF 내부 메타데이터 태그가 남아 있습니다: ' + ', '.join(map(str, sorted(found))))
                except RuntimeError:
                    raise
                except Exception:
                    pass
            return True
        raise RuntimeError('이 파일 형식은 메타데이터 제거 여부를 검증할 수 없습니다: ' + ext)

    def _clean_novelai_alpha(self, image):
        """Remove NovelAI stealth_pnginfo stored in the alpha-channel LSBs.

        NovelAI Inspect can recover prompt/artist tags from the least significant
        bit of each alpha value, even when EXIF/XMP/PNG text chunks are absent.
        For near-opaque alpha channels, dropping alpha entirely avoids introducing
        a faint transparency change. Otherwise clear each alpha LSB (maximum 1/255
        alpha change) while preserving the actual transparency shape.
        """
        rgba = image.convert('RGBA')
        alpha = rgba.getchannel('A')
        lo, hi = alpha.getextrema()
        if lo >= 254:
            # Such an alpha channel is visually opaque; discard the channel that
            # carries the hidden bits rather than preserve its covert payload.
            rgb = rgba.convert('RGB')
            rgba.close(); alpha.close()
            return rgb
        # NovelAI stealth metadata is encoded in alpha LSBs. Clear every LSB.
        table = [value & 0xFE for value in range(256)]
        clean_alpha = alpha.point(table)
        rgba.putalpha(clean_alpha)
        alpha.close(); clean_alpha.close()
        return rgba

    def save_image(self,src,dst):
        dst.parent.mkdir(parents=True,exist_ok=True)
        ext=dst.suffix.lower()
        same_format = ext == Path(src).suffix.lower()
        if self.remove_metadata_var.get() and same_format:
            if ext in ('.png', '.webp'):
                # Strip NovelAI's hidden alpha-channel payload as well as ordinary
                # file-container metadata. Container-only stripping is insufficient.
                temp_pixels = dst.with_name(dst.stem + '.__alpha_clean__' + dst.suffix)
                temp_clean = dst.with_name(dst.stem + '.__metadata_clean__' + dst.suffix)
                try:
                    with Image.open(src) as im:
                        im.seek(0); im.load()
                        clean = self._clean_novelai_alpha(im)
                        try:
                            if ext == '.png':
                                clean.save(temp_pixels, format='PNG', optimize=True)
                            else:
                                clean.save(temp_pixels, format='WEBP', lossless=True, method=6)
                        finally:
                            clean.close()
                    self._strip_metadata_lossless(temp_pixels, temp_clean)
                    self._verify_metadata_removed(temp_clean)
                    os.replace(temp_clean, dst)
                finally:
                    for q in (temp_pixels, temp_clean):
                        if q.exists(): q.unlink()
            else:
                self._strip_metadata_lossless(src,dst)
                self._verify_metadata_removed(dst)
            return
        if not self.remove_metadata_var.get() and same_format:
            shutil.copy2(src,dst)
            return
        # Format conversion necessarily re-encodes image data; metadata checkbox still prevents
        # source metadata from being copied, but pixel-perfect losslessness cannot be guaranteed.
        src_im=Image.open(src)
        clean=None
        try:
            from PIL import ImageOps
            src_im=ImageOps.exif_transpose(src_im)
            src_im.seek(0); src_im.load()
            if ext in ('.jpg','.jpeg'):
                clean=src_im.convert('RGB'); clean.save(dst,format='JPEG',quality=95,optimize=True,progressive=False)
            elif ext=='.png':
                clean=src_im.convert('RGBA') if src_im.mode not in ('1','L','LA','P','RGB','RGBA') else src_im.copy()
                if self.remove_metadata_var.get() and clean.mode in ('RGBA','LA'):
                    sanitized = self._clean_novelai_alpha(clean); clean.close(); clean = sanitized
                clean.save(dst,format='PNG',optimize=True)
            elif ext=='.webp':
                clean=src_im.convert('RGBA' if 'A' in src_im.getbands() else 'RGB')
                if self.remove_metadata_var.get() and clean.mode == 'RGBA':
                    sanitized = self._clean_novelai_alpha(clean); clean.close(); clean = sanitized
                clean.save(dst,format='WEBP',lossless=True,method=6)
            elif ext in ('.tif','.tiff'):
                clean=src_im.convert('RGBA' if 'A' in src_im.getbands() else 'RGB')
                clean.save(dst,format='TIFF',compression='tiff_deflate')
            elif ext=='.bmp':
                clean=src_im.convert('RGBA' if 'A' in src_im.getbands() else 'RGB')
                clean.save(dst,format='BMP')
            else:
                clean=src_im.convert('RGB'); clean.save(dst,format='PNG',optimize=True)
        finally:
            if clean is not None: clean.close()
            src_im.close()
        if self.remove_metadata_var.get():
            # Normalize the just-encoded file through the same container-level stripper.
            # This also removes encoder-added JPEG JFIF/APP markers and metadata from conversions.
            temp_clean = dst.with_name(dst.stem + '.__metadata_clean__' + dst.suffix)
            try:
                self._strip_metadata_lossless(dst, temp_clean)
                self._verify_metadata_removed(temp_clean)
                os.replace(temp_clean, dst)
            finally:
                if temp_clean.exists():
                    temp_clean.unlink()

    def execute(self):
        try:jobs=self.jobs()
        except Exception as e:messagebox.showerror('실행할 수 없습니다',str(e));return
        if not jobs:messagebox.showerror('실행할 수 없습니다','이름이 지정된 이미지가 없습니다.');return
        target=self.choose_output()
        if not target:return
        try:
            if self.save_mode.get()=='zip':
                with tempfile.TemporaryDirectory() as td:
                    td=Path(td);used=set()
                    for src,new in jobs:
                        sp=Path(src); ext=self.output_ext(sp); dest=td/(self.clean(new)+ext); n=2
                        while dest.name.lower() in used: dest=td/(self.clean(new)+f'_{n}'+ext); n+=1
                        used.add(dest.name.lower()); self.save_image(sp,dest)
                    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
                        for q in td.iterdir():z.write(q,q.name)
                if self.source_mode.get()=='rename':self.rename_originals(jobs)
            else:
                out=Path(target);used=set()
                if self.source_mode.get()=='rename':self.rename_originals(jobs)
                else:
                    for src,new in jobs:
                        sp=Path(src); ext=self.output_ext(sp); dest=out/(self.clean(new)+ext); n=2
                        while dest.name.lower() in used or dest.exists(): dest=out/(self.clean(new)+f'_{n}'+ext); n+=1
                        used.add(dest.name.lower()); self.save_image(sp,dest)
            messagebox.showinfo('완료',f'{len(jobs)}개 이미지의 이름 변경이 완료되었습니다.')
        except Exception as e:messagebox.showerror('오류',f'처리 중 오류가 발생했습니다.\n\n{e}')

    def rename_originals(self,jobs):
        temps=[]
        for i,(src,new) in enumerate(jobs):
            sp=Path(src);tmp=sp.with_name(f'.__rename_tmp_{i}_{sp.name}');shutil.move(str(sp),str(tmp));temps.append((tmp,sp,new))
        try:
            for tmp,orig,new in temps:
                dest=orig.with_name(self.clean(new)+self.output_ext(tmp))
                if self.remove_metadata_var.get() or dest.suffix.lower()!=tmp.suffix.lower():
                    clean=dest.with_name('.__clean_'+dest.name)
                    self.save_image(tmp,clean)
                    os.replace(clean,dest)
                    tmp.unlink(missing_ok=True)
                else:
                    os.replace(tmp,dest)
        except Exception:
            for tmp,orig,_ in temps:
                if tmp.exists() and not orig.exists():shutil.move(str(tmp),str(orig))
            raise

if __name__=='__main__':
    ImageRenamer().mainloop()
