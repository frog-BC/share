@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo Image Renamer v14 - EXE Build
echo ==========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python이 설치되어 있지 않습니다.
  pause
  exit /b 1
)
py -m pip install --upgrade pip
py -m pip install pillow pyinstaller
if errorlevel 1 (
  echo 필요한 패키지 설치 실패
  pause
  exit /b 1
)
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist ImageRenamer.spec del /q ImageRenamer.spec
pyinstaller --noconfirm --clean --onefile --windowed --name ImageRenamer ImageRenamer.py
if errorlevel 1 (
  echo.
  echo ===== 빌드 실패 =====
  pause
  exit /b 1
)
echo.
echo ===== 빌드 완료 =====
echo dist\ImageRenamer.exe
echo.
pause
